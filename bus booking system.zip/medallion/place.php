<!DOCTYPE html>


<head>
	
<meta charset="utf-8">
	
<meta name="viewport" content="width=devidev-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	
<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Bus Online Ticketing Booking System</title>
	
	
<!-- [ FONT-AWESOME ICON ] 
        
=========================================================================================================================-->
	
<link rel="stylesheet" type="text/css" href="library/font-awesome-4.3.0/css/font-awesome.min.css">

	
<!-- [ PLUGIN STYLESHEET ]
        
=========================================================================================================================-->
	
<link rel="shortcut icon" type="image/x-icon" href="images/icon.png">
	
<link rel="stylesheet" type="text/css" href="css/animate.css">
	
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
        
<link rel="stylesheet" type="text/css" href="css/owl.theme.css">
	
<link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
	
<!-- [ Boot STYLESHEET ]
        
=========================================================================================================================-->
	
<link rel="stylesheet" type="text/css" href="library/bootstrap/css/bootstrap-theme.min.css">
	
<link rel="stylesheet" type="text/css" href="library/bootstrap/css/bootstrap.css">
       
<!-- [ DEFAULT STYLESHEET ] 
        
=========================================================================================================================-->
	
<link rel="stylesheet" type="text/css" href="css/style.css">
        
<link rel="stylesheet" type="text/css" href="css/responsive.css">
	
<link rel="stylesheet" type="text/css" href="css/color/rose.css">
        

</head>
<body >

    
<nav  class=" nim-menu navbar navbar-default navbar-fixed-top">
      
<div class="container">
        
<!-- Brand and toggle get grouped for better mobile display -->
        
<div class="navbar-header">
          
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            
<span class="sr-only">Toggle navigation</span>
            
<span class="icon-bar"></span>
            
<span class="icon-bar"></span>
            
<span class="icon-bar"></span>
          
</button>
            
<a class="navbar-brand" href="contact.html">BusOnline<span class="themecolor">Ticketing Booking</span>System</a>
        
</div>

        
<!-- Collect the nav links, forms, and other content for toggling -->
        
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          
<ul class="nav navbar-nav navbar-right">
            
<li><a href="index.php" class="page-scroll"><h3>Home</h3></a></li>
            
<li><a href="index.php" class="page-scroll"><h3>About</h3></a></li>
                                   
<li><a href="place.php" class="page-scroll"><h3>Place</h3></a></li>
                                        
<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-expanded="false">
         <h3>Language</h3>
    </a>
    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Malay</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Chinese</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">English</a></div>
          
<li><a href="contact.php" class="page-scroll"><h3>Contact</h3></a></li>

<li><a href="admin/" class="page-scroll"><h3>Login</h3></a></li>

<li><a href="registration.php" class="page-scroll"><h3>Register</h3></a></li>
          
</ul>
        
</div>
<!-- /.navbar-collapse -->
      
</div><!-- /.container-fluid -->
    
</nav>

<div class="col-sm-6">
                    <div style="margin-top: 80px; margin-left: 250px;">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.388106476252!2d103.67892554177345!3d1.5341737109888838!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31da73c109632e0b%3A0x74cda51bf210c304!2sSouthern%20University%20College!5e0!3m2!1sen!2smy!4v1649392475162!5m2!1sen!2smy" width="1000" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
                </div>
                </div>
                
<section class="sub-form text-center" id="eight">

<div class="container">
    <div class="col-md-12">
        
<h3 class="title">Subscribe to our <span class="themecolor">Bus Booking</span></h3>
            
<p class="lead">Bus Booking System provides the largest bus in South East Asia. We are proud to offer the vast selection of choices, instant confirmation and secure online transport ticket and service booking.</p>
    
</div> 
    
<div class="row">
        
<div class="col-md-3 col-sm-3"></div>
      
<div class="col-md-6 center-block col-sm-6 ">
        
<form id="mc-form">
          
<div class="input-group">
            
<input type="email" class="form-control" placeholder="Email Address" required id="mc-email">
           
<span class="input-group-btn">
            
<button type="submit" class="btn btn-default">SUBSCRIBE <i class="fa fa-envelope"></i> </button>
            
</span></div>
          
<label for="mc-email" id="mc-notification"></label>
       
 </form>
      
</div>
   
 </div>

 <div id="footer">
    <div class="outer clearfix">
        <div class="col-sm-12">
            <span class="title">Pages</span>
            <ul class="footer">
                <li><a href="index.php">About Us</a></li>
                <li><a href="/faq">FAQ</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="place.php">Site Map</a></li>
                <li><a href="/careers">Careers</a></li>
            </ul>
        </div>
</div>

</div>

</section>

<!--sub-form end--> 


 
 
<!-- [/CONTACT]
 
============================================================================================================================-->
 
 
 
<!-- [FOOTER]
 
============================================================================================================================-->
 

<footer class="site-footer section-spacing text-center " id="eight">
    
  
<div class="container">
    
<div class="row">
      
<div class="col-md-4">
        
<p class="footer-links"><a href="#">Terms of Use</a> <a href="#">Privacy Policy</a></p>
      
</div>
      
<div class="col-md-4"> <small>&copy; 2022 SUC. All rights reserved.</small></div>
      
<div class="col-md-4"> 
        
<!--social-->
        
        
<ul class="social">
          
<li><a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter "></i></a></li>
          
<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
          
<li><a href="https://www.youtube.com/" target="_blank"><i class="fa fa-youtube-play"></i></a></li>
        
</ul>
        
        
<!--social end--> 
        
      
</div>
    
</div>
  
</div>

</footer>
