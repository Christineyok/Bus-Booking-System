<?php 
require_once('database/Database.php');
if(session_status() == PHP_SESSION_NONE)
{
	session_start();//start session if session not start
}

$db = new Database();

// $sql = "SELECT *
// 		FROM accomodation;
// 		ORDER BY acc_price ASC;
// ";
// $accomodations = $db->getRows($sql);

$sqlGetSit = "SELECT * 
			   FROM accomodation
			   WHERE acc_id = ?;
";

$getSit = $db->getRow($sqlGetSit, [1]);//1 means sitting

$date = $_SESSION['departure_date'];
//with ana nga date
$sqlBookedSit = "SELECT COUNT(*) as sit
				 FROM booked 
				 WHERE acc_id = ?
				 AND book_departure = ? 
";
$totalSit = $db->getRow($sqlBookedSit, [1, $date]);


// ika duha
$sqlEcoA = "SELECT * 
			   FROM accomodation
			   WHERE acc_id = ?;
";
$getEcoA = $db->getRow($sqlEcoA, [2]);//1 means sitting

$sqlBookedEcoA = "SELECT COUNT(*) as ecoA
				 FROM booked 
				 WHERE acc_id = ?
				 AND book_departure = ?; 
	";
$totalEcoA = $db->getRow($sqlBookedEcoA, [2, $date]);	


//ika 3 Eco B
$sqlEcoB = "SELECT * 
			   FROM accomodation
			   WHERE acc_id = ?;
";
$getEcoB = $db->getRow($sqlEcoB, [3]);//1 means sitting

$sqlBookedEcoB = "SELECT COUNT(*) as ecoB
				 FROM booked 
				 WHERE acc_id = ?
				 AND book_departure = ?; 
	";
$totalEcoB = $db->getRow($sqlBookedEcoB, [3, $date]);	

//get trasactions


$db->Disconnect();