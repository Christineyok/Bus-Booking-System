﻿<!DOCTYPE html>


<head>
	
<meta charset="utf-8">
	
<meta name="viewport" content="width=devidev-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	
<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Bus Online Ticketing Booking System</title>
	
	
<!-- [ FONT-AWESOME ICON ] 
        
=========================================================================================================================-->
	
<link rel="stylesheet" type="text/css" href="library/font-awesome-4.3.0/css/font-awesome.min.css">

	
<!-- [ PLUGIN STYLESHEET ]
        
=========================================================================================================================-->
	
<link rel="shortcut icon" type="image/x-icon" href="images/icon.png">
	
<link rel="stylesheet" type="text/css" href="css/animate.css">
	
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
        
<link rel="stylesheet" type="text/css" href="css/owl.theme.css">
	
<link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
	
<!-- [ Boot STYLESHEET ]
        
=========================================================================================================================-->
	
<link rel="stylesheet" type="text/css" href="library/bootstrap/css/bootstrap-theme.min.css">
	
<link rel="stylesheet" type="text/css" href="library/bootstrap/css/bootstrap.css">
       
<!-- [ DEFAULT STYLESHEET ] 
        
=========================================================================================================================-->
	
<link rel="stylesheet" type="text/css" href="css/style.css">
        
<link rel="stylesheet" type="text/css" href="css/responsive.css">
	
<link rel="stylesheet" type="text/css" href="css/color/rose.css">
        

</head>
<body >

<!-- [ LOADERs ]

================================================================================================================================-->
	
    <div class="preloader">
    
<div class="loader theme_background_color">
        
<span></span>
      
    
</div>
</div>
<!-- [ /PRELOADER ]

=============================================================================================================================-->

<!-- [WRAPPER ]

=============================================================================================================================-->

<div class="wrapper">
  
<!-- [NAV]
 
============================================================================================================================-->    
   
<!-- Navigation
    ==========================================-->
    
<nav  class=" nim-menu navbar navbar-default navbar-fixed-top">
      
<div class="container">
        
<!-- Brand and toggle get grouped for better mobile display -->
        
<div class="navbar-header">
          
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            
<span class="sr-only">Toggle navigation</span>
            
<span class="icon-bar"></span>
            
<span class="icon-bar"></span>
            
<span class="icon-bar"></span>
          
</button>
            
<a class="navbar-brand" href="index.html">BusOnline<span class="themecolor">Ticketing Booking</span>System</a>
        
</div>

        
<!-- Collect the nav links, forms, and other content for toggling -->
        
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          
<ul class="nav navbar-nav navbar-right">
            
<li><a href="index.php" class="page-scroll"><h3>Home</h3></a></li>
            
<li><a href="#one" class="page-scroll"><h3>About</h3></a></li>
                                   
<li><a href="place.php" class="page-scroll"><h3>Place</h3></a></li>
                                        
<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-expanded="false">
         <h3>Language</h3>
    </a>
    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Malay</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Chinese</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="index.php">English</a></div>
          
<li><a href="contact.php" class="page-scroll"><h3>Contact</h3></a></li>

<li><a href="admin/" class="page-scroll"><h3>Login</h3></a></li>

<li><a href="registration.php" class="page-scroll"><h3>Register</h3></a></li>
          
</ul>
        
</div>
<!-- /.navbar-collapse -->
      
</div><!-- /.container-fluid -->
    
</nav>


   
<!-- [/NAV]
 
============================================================================================================================--> 
    
   
<!-- [/MAIN-HEADING]
 
============================================================================================================================--> 
   
<section class="main-heading" id="home">
       
<div class="overlay">
           
<div class="container">
               
<div class="row">
                   
<div class="main-heading-content col-md-12 col-sm-12 text-center">
        
<h1 class="main-heading-title"><span class="main-element themecolor" data-elements=" Bus Online, Bus Online, Bus Online"></span></h1>
 
<h1 class="main-heading-title"><span class="main-element themecolor" data-elements=" Ticketing Booking System, Ticketing Booking System, Ticketing Booking System"></span></h1>
       
<p class="main-heading-text">Want to buy bus tickets online? <br/>Trusted by millions of happy customers worldwide, Bus Booking Online is your one-stop online bus ticket booking solution.Choose from over 50 bus operators,  <br/>check bus schedules and book bus tickets online from the comfort of your home.The platform has  revolutionized the process of booking bus tickets online </br>by enhancing its inventory of bus operators covering different routes in Malaysia and Singapore.</p>
        
<div class="btn-bar">
          
<a href="reserved.php" class="btn btn-custom theme_background_color">Reserved Now</a>
                 
</div>
      
</div>
               
</div>
           
</div>
       
</div>  
      
   
</section>
 
<section class="main-heading" id="two">
       
<div class="overlay">
           
<div class="container">
               
<div class="row">
                   
<div class="main-heading-content col-md-12 col-sm-12 text-center">
        
<h1 class="main-heading-title">We are Creative</h1>
        
<p class="main-heading-text">Bus Online Booking has implemented a transparent, simple, and secure mode of booking online bus tickets.</br> With a wide range of shuttle buses, express buses, night buses, and affordable coaches available on its platform,</br> Bus Online Booking gives its customers an opportunity to grab exciting offers and deals and enjoy a discounted trip. </br>Book a bus online on Bus Online Booking for a safe, convenient, and memorable trip!</p>
        
<div class="btn-bar">
          
<a href="contact.php" class="btn btn-custom-outline theme_background_color">Contact Us</a>
        
</div>
      
</div>
               
</div>
           
</div>
       
</div>  
      
   
</section>
    
 
<!-- [/MAIN-HEADING]
 
============================================================================================================================-->
 
 
 
<!-- [ABOUT US]
 
============================================================================================================================-->
 
<section class="aboutus white-background black" id="one">
     
<div class="container">
         
<div class="row">
             
<div class="col-md-12 text-center black">
                 
<h3 class="title">ABOUT <span class="themecolor">US</span></h3>
            
<p class="a-slog">Our core value is to continually provide the best service to all of our clients. We offer one of the most hassle-free booking experiences in the industry. With just a few clicks, you're ready to travel to your favorite destinations. Booking with busonlinebooking has never been easier! Just search, book, and go!</p> 
             
</div>
         
</div>
         
<div class="gap">
             
         
</div>
         
         
<div class="row about-box">
          
<div class="col-sm-4 text-center">
            
<div class="margin-bottom">
              
<i class="fa fa-newspaper-o"></i>
              
<h4>POWER OF FLEXIBILITY</h4>
              
<p class="black">What if you are not able to travel as per the plan? Be wise, book on operators offering Cancellation or Reschedule policy and make your plans as flexible as you like.
</p>
            
</div> <!-- / margin -->
          
</div> <!-- /col -->
          
<div class="col-sm-4 about-line text-center">
            
<div class="margin-bottom">
              
<i class="fa fa-diamond"></i>
              
<h4>FULLY RESPONSIVE</h4>
              
<p class="black">Our bus online booking is committed to maintaining the user experience and appearance of all devices so that customers do not have to experience annoying zooming, scrolling or resizing, and our bus online booking will ensure that it will be 100% responsive to the user experience.</p>
            
</div> <!-- / margin -->
          
</div><!-- /col -->
          
<div class="col-sm-4 text-center">
            
<div class="margin-bottom">
              
<i class="fa fa-area-chart"></i>
              
<h4>SECURE PAYMENTS</h4>
              
<p class="black"> BusOnlineBooking has the highest security standards and keeps your information and purchases completely safe and secure.
 </p>
            
</div> <!-- / margin -->
          
</div><!-- /col -->
        
</div> <!-- /row -->
         
         
         
         
     
</div>
 </section>
 
 
 
<!-- [/ABOUTUS]
 
 
============================================================================================================================-->
 
 
 
 
 
<!-- [PLACE]
 
============================================================================================================================-->
 
<section class="place" id="four">
     
<div class="overlay">
         
<div class="container">
             
<div class="row">
                
 <article class="col-md-12 text-center">
           
 <div class="intermediate-container">
             
 <div class="subheading">
                 
 <h4>Are You Ready To <span class="themecolor">Enjoy?</span></h4>
           
   </div>
             
 <div class="heading">
              
  <h2>Choose your place in here!</h2>
          
    </div>
              
<div class="">
              
  <a class="btn btn-custom-outline" href="place.php"><span>Get started</span></a>
        
      </div>
        
    </div>
       
   </article>
       
      </div>
    
    </div>
    
 </div>
 
</section>
 
 
<!-- [/PLACE]
 

============================================================================================================================-->
 
 
<!-- [/SERVICES]
 
============================================================================================================================-->
 
 
 
<section class="services white-background black" id="seven">
     
 <div class="container">
        
<div class="row text-center">
          
<div class="col-md-12">
              
<h3 class="title">We Are <span class="themecolor">Good In</span></h3>
            
<p class="a-slog">Easily and smoothly purchase tickets using only a few basic operations.</p>
          
</div> <!-- /col -->
        
</div> <!-- /row -->
        
<div class="gap"></div>

        
<div class="row">
          
<div class="col-sm-4">
            
<div class="nim-service margin-bottom">
              
<i class="fa fa-diamond"></i>
              
<div class="nim-service-detail">
                
<h4>Largest Land & Sea Transportation Online Booking Platform in Southeast Asia</h4>
                
<p>We are the largest online booking platform for land and sea transportation services in all Southeast Asia offering various travel tickets to help you connect to spectacular destinations.</p>
   
           </div> <!-- /nim-service-detail -->
            
</div> <!-- /nim-service margin-bottom -->
          
</div> <!-- /col -->

          
<div class="col-sm-4">
            
<div class="nim-service margin-bottom">
             
 <i class="fa fa-tablet"></i>
             
 <div class="nim-service-detail">
              
  <h4>Trustworthy</h4>
              
  <p>With over 13 years of experience within the transportation industry, we have established a strong background history through our success and is always aiming to deliver only quality services.</p>
 
             </div> <!-- /nim-service-detail -->
            
</div> <!-- /nim-service margin-bottom -->
          
</div> <!-- /col -->

          
<div class="col-sm-4">
            
<div class="nim-service margin-bottom">
              
<i class="fa fa-magic"></i>
              
<div class="nim-service-detail">
                
<h4>Various Payment Options</h4>
                
<p>Select from a range of payment options and currencies made available to help you make your purchase conveniently.</p>
 
             </div> <!-- /nim-service-detail -->
            
</div> <!-- /nim-service margin-bottom -->
         
 </div> <!-- /col -->       
        
</div> <!-- end row -->

        
<div class="row">
          
<div class="col-sm-4">
            
<div class="nim-service margin-bottom">
             
 <i class="fa fa-rocket"></i>
             
 <div class="nim-service-detail">
               
 <h4>Honest Price</h4>
                
<p>What you see is what you pay. No price inflation. No hidden fees. We offer you quality services and amazing deals at affordable prices.</p>
          
    </div> <!-- /nim-service-detail -->
            
</div> <!-- /nim-service margin-bottom -->
         
 </div> <!-- /col -->

          
<div class="col-sm-4">
           
 <div class="nim-service margin-bottom">
              
<i class="fa fa-map-marker"></i>
              
<div class="nim-service-detail">
                
<h4>Discounts & Promotions</h4>
                
<p>Frequent promotions are up for grab! Check out great discounts and sales from time to time to enjoy lower prices.</p>
             
 </div> <!-- /nim-service-detail -->
            
</div> <!-- /nim-service margin-bottom -->
          
</div> <!-- /col -->

          
<div class="col-sm-4">
            
<div class="nim-service margin-bottom">
             
 <i class="fa fa-paypal"></i>
              
<div class="nim-service-detail">
               
 <h4>Earn Easipoints</h4>
                
<p>Be rewarded with every ticket purchase. Collect our EasiPoints every time you make a purchase and make redemptions to earn a price cut for your next purchase!</p>
              
</div> <!-- /nim-service-detail -->
            
</div> <!-- /nim-service margin-bottom -->
          
</div> <!-- /col -->         
        
</div> <!-- end row -->

      
</div>  <!-- container -->
    
</section>
 
 
 
<!-- [/SERVICES]
 
============================================================================================================================-->
 
 
 
<!-- [CONTACT]
 
============================================================================================================================-->
 
<!--sub-form-->
<section class="sub-form text-center" id="eight">
  
<div class="container">
    <div class="col-md-12">
        
    <h3 class="title">Subscribe to our <span class="themecolor">Bus Booking</span></h3>
            
            <p class="lead">Bus Booking System provides the largest bus in South East Asia. We are proud to offer the vast selection of choices, instant confirmation and secure online transport ticket and service booking.</p>
                
            </div> 
    
<div class="row">
        
<div class="col-md-3 col-sm-3"></div>
      
<div class="col-md-6 center-block col-sm-6 ">
        
<form id="mc-form">
          
<div class="input-group">
            
<input type="email" class="form-control" placeholder="Email Address" required id="mc-email">
           
<span class="input-group-btn">
            
<button type="submit" class="btn btn-default">SUBSCRIBE <i class="fa fa-envelope"></i> </button>
            
</span></div>
          
<label for="mc-email" id="mc-notification"></label>
       
 </form>
      
</div>
   
 </div>

<div id="footer">
    <div class="outer clearfix">
        <div class="col-sm-12">
            <span class="title">Pages</span>
            <ul class="footer">
                <li><a href="index.php">About Us</a></li>
                <li><a href="/faq">FAQ</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="place.php">Site Map</a></li>
                <li><a href="/careers">Careers</a></li>
            </ul>
        </div>
  
</div>

</div>

</section>

<!--sub-form end--> 


 
 
<!-- [/CONTACT]
 
============================================================================================================================-->
 
 
 
<!-- [FOOTER]
 
============================================================================================================================-->
 

<footer class="site-footer section-spacing text-center " id="eight">
    
  
<div class="container">
    
<div class="row">
      
<div class="col-md-4">
        
<p class="footer-links"><a href="#">Terms of Use</a> <a href="#">Privacy Policy</a></p>
      
</div>
      
<div class="col-md-4"> <small>&copy; 2022 SUC. All rights reserved.</small></div>
      
<div class="col-md-4"> 
        
<!--social-->
        
        
<ul class="social">
          
<li><a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter "></i></a></li>
          
<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
          
<li><a href="https://www.youtube.com/" target="_blank"><i class="fa fa-youtube-play"></i></a></li>
        
</ul>
        
        
<!--social end--> 
        
      
</div>
    
</div>
  
</div>

</footer>

 
 
 
<!-- [/FOOTER]
 
============================================================================================================================-->
 
 
 

</div>
 

<!-- [ /WRAPPER ]

=============================================================================================================================-->

	
<!-- [ DEFAULT SCRIPT ] -->
	
<script src="library/modernizr.custom.97074.js"></script>
	
<script src="library/jquery-1.11.3.min.js"></script>
        
<script src="library/bootstrap/js/bootstrap.js"></script>
	
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>	
	
<!-- [ PLUGIN SCRIPT ] -->
        
<script src="library/vegas/vegas.min.js"></script>
	
<script src="js/plugins.js"></script>
        
<!-- [ TYPING SCRIPT ] -->
         
<script src="js/typed.js"></script>
         
<!-- [ COUNT SCRIPT ] -->
         
<script src="js/fappear.js"></script>
       
<script src="js/jquery.countTo.js"></script>
	
<!-- [ SLIDER SCRIPT ] -->  
        
<script src="js/owl.carousel.js"></script>
         
<script src="js/jquery.magnific-popup.min.js" type="text/javascript"></script>
        
<script type="text/javascript" src="js/SmoothScroll.js"></script>
        
        
<!-- [ COMMON SCRIPT ] -->
	<script src="js/common.js"></script>
  
</body>


</html>











